import { useNavigate } from "react-router-dom";

export default function App() {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    navigate("/login");
  };

  return (
    <div>
      <nav style={{ padding: "1rem", backgroundColor: "#eee" }}>
        <a href="/" style={{ marginRight: "1rem" }}>Home</a>
        {localStorage.getItem("isLoggedIn") === "true" && (
          <button onClick={handleLogout}>Logout</button>
        )}
      </nav>

    </div>
  );
}