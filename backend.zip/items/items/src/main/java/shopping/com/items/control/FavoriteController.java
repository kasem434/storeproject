package shopping.com.items.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import shopping.com.items.repository.FavoriteItemRepository;
import shopping.com.items.service.FavoriteItem;

import java.util.List;

@RestController
@RequestMapping("/api/favorites")
public class FavoriteController {

    @Autowired
    private FavoriteItemRepository repository;

    @GetMapping("/{userId}")
    public List<FavoriteItem> getFavorites(@PathVariable Long userId) {
        return repository.findByUserId(userId);
    }

    @PostMapping
    public FavoriteItem addFavorite(@RequestBody FavoriteItem item) {
        return repository.save(item);
    }

    @DeleteMapping
    public void deleteFavorite(@RequestParam Long userId, @RequestParam Long productId) {
        repository.deleteByUserIdAndProductId(userId, productId);
    }
}
