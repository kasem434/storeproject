package shopping.com.items;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Items {
	public static void main(String[] args) {
		SpringApplication.run(Items.class, args);
	}
}
