import { useParams, Link } from "react-router-dom";

export default function OrderSuccess() {
  const { id } = useParams();

  return (
    <div style={{ padding: "2rem" }}>
      <h2>🎉 Order Placed Successfully!</h2>
      <p>Your order ID is <strong>{id}</strong>.</p>
      <Link to="/">⬅ Back to Store</Link>
    </div>
  );
}
