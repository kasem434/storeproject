package shopping.com.items.orders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import shopping.com.items.orders.Order;
import shopping.com.items.orders.OrderItem;
import shopping.com.items.repository.OrderItemRepository;
import shopping.com.items.repository.OrderRepository;
import shopping.com.items.orders.OrderStatus;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private OrderItemRepository orderItemRepository;

    public List<Order> getOrdersByUserId(Long userId) {
        return orderRepository.findByUserId(userId);
    }

    public Optional<Order> getTempOrderByUserId(Long userId) {
        return orderRepository.findByUserIdAndStatus(userId, "TEMP");
    }

    public Order createTempOrder(Long userId) {
        Order order = new Order();
        order.setUserId(userId);
        order.setOrderDate(LocalDateTime.now());
        order.setStatus(OrderStatus.valueOf("TEMP"));
        order.setTotalPrice(0);
        order.setShippingAddress("");
        return orderRepository.save(order);
    }

    public Order addItemToTempOrder(Long userId, OrderItem item) {
        Order order = getTempOrderByUserId(userId).orElseGet(() -> createTempOrder(userId));
        item.setOrder(order);
        orderItemRepository.save(item);

        // Update total price
        double totalPrice = order.getOrderItems().stream()
                .mapToDouble(i -> i.getPrice() * i.getQuantity())
                .sum();
        order.setTotalPrice(totalPrice);
        return orderRepository.save(order);
    }

    public Order closeOrder(Long orderId, String shippingAddress) {
        Optional<Order> optionalOrder = orderRepository.findById(orderId);
        if (optionalOrder.isPresent()) {
            Order order = optionalOrder.get();
            order.setStatus(OrderStatus.valueOf("Close"));
            order.setShippingAddress(shippingAddress);
            order.setOrderDate(LocalDateTime.now());

            // Recalculate total just in case
            double totalPrice = order.getOrderItems().stream()
                    .mapToDouble(i -> i.getPrice() * i.getQuantity())
                    .sum();
            order.setTotalPrice(totalPrice);

            return orderRepository.save(order);
        }
        throw new RuntimeException("Order not found");
    }

    public void removeItemFromOrder(Long orderItemId) {
        orderItemRepository.deleteById(orderItemId);
    }
}
