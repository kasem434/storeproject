import { useEffect, useState } from "react";

export default function FavoritesPage() {
  const userId = localStorage.getItem("userId");
  const [favorites, setFavorites] = useState([]);
  const [products, setProducts] = useState([]);


  useEffect(() => {
    fetch("http://localhost:8080/api/products")
      .then((res) => res.json())
      .then((data) => setProducts(data));
  }, []);


  useEffect(() => {
    fetch(`http://localhost:8080/api/favorites/${userId}`)
      .then((res) => res.json())
      .then((data) => {
        const favProductIds = data.map(fav => fav.productId);
        setFavorites(favProductIds);
      });
  }, [userId]);

  const removeFromFavorites = (productId) => {
    console.log("Remove clicked for productId:", productId); 

    fetch(`http://localhost:8080/api/favorites?userId=${userId}&productId=${productId}`, {
      method: "DELETE",
    })
      .then(() => {
        setFavorites(prev => prev.filter(id => id !== productId));
      })
      .catch((err) => {
        console.error("Failed to remove favorite", err);
      });
  };

  const favoriteProducts = products.filter(product => favorites.includes(product.id));

  return (
    <div style={{ padding: "2rem" }}>
      <h2>⭐ Your Favorites</h2>
      {favoriteProducts.length === 0 ? (
        <p>No favorite items found.</p>
      ) : (
        <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem" }}>
          {favoriteProducts.map(item => (
            <div key={item.id} style={{
              border: "1px solid #ccc",
              padding: "1rem",
              borderRadius: "8px",
              width: "150px",
              textAlign: "center"
            }}>
              <img src={item.imageUrl} alt={item.title} style={{ width: "100%", height: "150px", objectFit: "cover" }} />
              <h4>{item.title}</h4>
              <button onClick={() => removeFromFavorites(item.id)}>Remove ⭐</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
