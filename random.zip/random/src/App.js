import { Routes, Route } from "react-router-dom";
import { useEffect, useState } from "react";

import ProductList from "./ProductList";
import LoginForm from "./login";
import SignupForm from "./signup";
import AboutPage from "./page";
import FavoritesPage from "./FavoritesPage";
import OrderList from './OrderList';
import OrderSuccess from "./OrderSuccess";
import OrderProcess from "./OrderProcess";
import OrderDetails from "./OrderDetails";

function App() {
  const loggedInUserId = localStorage.getItem("userId");
  const [products, setProducts] = useState([]);


  useEffect(() => {
    fetch("http://localhost:8080/api/products")
      .then(res => res.json())
      .then(data => setProducts(data))
      .catch(err => console.error("Error fetching products:", err));
  }, []);

  return (
    <Routes>
      <Route path="/" element={<ProductList />} />
      <Route path="/login" element={<LoginForm />} />
      <Route path="/signup" element={<SignupForm />} />
      <Route path="/about" element={<AboutPage />} />
      
      
      <Route
        path="/favorites"
        element={
          <FavoritesPage
            loggedInUserId={loggedInUserId}
            products={products}
          />
        }
      />
      
      <Route path="/orders" element={<OrderList userId={loggedInUserId} />} />
      <Route path="/order-success/:id" element={<OrderSuccess />} />
      <Route path="/order/:orderId/edit" element={<OrderProcess />} />
      <Route path="/order/:orderId" element={<OrderDetails />} />
    </Routes>
  );
}

export default App;
