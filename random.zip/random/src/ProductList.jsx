import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import OrderList from './OrderList';

export default function ProductList() {
  const initialProducts = [
    { id: 1, title: "max payne 2", price: 15.99, image: "https://m.media-amazon.com/images/I/41vDEl8z2EL._SY430_SX215_QL70_FMwebp_.jpg", stock: 10 },
    { id: 2, title: "call of duty world at war", price: 29.99, image: "https://i.ebayimg.com/images/g/TasAAOSwYp5j2sw5/s-l1600.webp", stock: 5 },
    { id: 3, title: "Assassin's Creed", price: 59.99, image: "https://www.platinumgameservices.co.uk/prodimgs/PGS_2414_1710157626.png", stock: 0 },
    { id: 4, title: "bully", price: 59.99, image: "https://www.platinumgameservices.co.uk/prodimgs/Bully-Achievements-Xbox-360-Game.png", stock: 10 },
    { id: 5, title: "far cry3", price: 29.99, image: "https://www.platinumgameservices.co.uk/prodimgs/Far-Cry-3-Achievements-Xbox-360-Game.png", stock: 5 },
    { id: 6, title: "L.A. Noire", price: 79.99, image: "https://www.platinumgameservices.co.uk/prodimgs/L-A-Noire-Achievements-Xbox-360-Game.png", stock: 0 },
    { id: 7, title: "Farming Simulator", price: 59.99, image: "https://www.platinumgameservices.co.uk/prodimgs/Farming-Simulator-15-Achievements-Xbox-360-Game.png", stock: 10 },
    { id: 8, title: "gears of war 2", price: 29.99, image: "https://store-images.s-microsoft.com/image/apps.45516.65595136073047161.857e51a5-2b52-4c0e-8ac2-92b6b4609fc2.d6aede50-9d8f-4813-9417-fab3a1d88e74", stock: 5 },
    { id: 9, title: "call of duty 4", price: 79.99, image: "https://store-images.s-microsoft.com/image/apps.23065.64885830279055674.bddbfbcd-ded1-4f52-b344-10a98e886656.ade407ea-be79-465b-871f-47885d7fb443", stock: 0 },
    { id: 10, title: "red dead redemption", price: 79.99, image: "https://media.gamestop.com/i/gamestop/11102347/Red-Dead-Redemption-Game-of-the-Year-Edition?$pdp$", stock: 19 },
    { id: 11, title: "prototype 2", price: 10.99, image: "https://m.media-amazon.com/images/I/71khkaxtd7L.jpg", stock: 4 },
    { id: 12, title: "halo 2", price: 1.99, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTtEmsBu32HDeNbZxvcX-17zUwlrsFqqw1DDQ&s", stock: 33 },
    { id: 13, title: "halo 3", price: 2.99, image: "https://m.media-amazon.com/images/I/813gXz6Vi0L.jpg", stock: 21 },
    { id: 14, title: "halo 4", price: 4.99, image: "https://m.media-amazon.com/images/I/91T4yYM0eGL._AC_UF894,1000_QL80_.jpg", stock: 12 },
    { id: 15, title: "halo", price: 1.99, image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRi5ZXEdnrC1LH124dwiB51vjQj19SsXZBWTA&s", stock: 0 },
  ];

  const [products, setProducts] = useState(initialProducts);
  const [cart, setCart] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [shippingAddress, setShippingAddress] = useState("");
  const [favorites, setFavorites] = useState([]);
  const [showOrders, setShowOrders] = useState(false);
  const [favoriteMessage, setFavoriteMessage] = useState("");

  const navigate = useNavigate();
  const loggedInUserId = localStorage.getItem("userId");

  useEffect(() => {
    if (!loggedInUserId) return;

    fetch(`http://localhost:8080/api/favorites/${loggedInUserId}`)
      .then(res => res.json())
      .then(data => {
        const favIds = data.map(fav => fav.productId);
        setFavorites(favIds);
      })
      .catch(err => console.error("Failed to load favorites", err));
  }, [loggedInUserId]);

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("userId");
    navigate("/login");
  };

  const addToFavorites = (item) => {
    if (!loggedInUserId) {
      alert("You must be logged in to add favorites.");
      return;
    }
    fetch("http://localhost:8080/api/favorites", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId: Number(loggedInUserId), productId: item.id })
    })
      .then(res => {
        if (res.ok) {
          setFavorites(prev => [...prev, item.id]);
          setFavoriteMessage(`✅ Added "${item.title}" to favorites!`);
          setTimeout(() => setFavoriteMessage(""), 2000);
        } else {
          alert("Failed to add favorite");
        }
      })
      .catch(() => alert("Failed to add favorite"));
  };

  const removeFromFavorites = (productId) => {
    if (!loggedInUserId) {
      alert("You must be logged in to remove favorites.");
      return;
    }
    fetch(`http://localhost:8080/api/favorites?userId=${loggedInUserId}&productId=${productId}`, {
      method: "DELETE",
    })
      .then(res => {
        if (res.ok) {
          setFavorites(prev => prev.filter(id => id !== productId));
        } else {
          alert("Failed to remove favorite");
        }
      })
      .catch(() => alert("Failed to remove favorite"));
  };

  const filteredProducts = products.filter((item) => {
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStock =
      selectedCategory === "available"
        ? item.stock > 0
        : selectedCategory === "unavailable"
          ? item.stock === 0
          : true;
    return matchesSearch && matchesStock;
  });

  const addToCart = (item) => {
    if (item.stock === 0) return;

    setProducts((prevProducts) =>
      prevProducts.map((p) =>
        p.id === item.id ? { ...p, stock: p.stock - 1 } : p
      )
    );

    setCart((prevCart) => {
      const existingItem = prevCart.find(i => i.id === item.id);
      if (existingItem) {
        return prevCart.map(i =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
        );
      } else {
        return [...prevCart, { ...item, quantity: 1 }];
      }
    });
  };

  const removeFromCart = (indexToRemove) => {
    setProducts((prevProducts) => {
      const itemToRemove = cart[indexToRemove];
      if (!itemToRemove) return prevProducts;

      return prevProducts.map(p =>
        p.id === itemToRemove.id ? { ...p, stock: p.stock + itemToRemove.quantity } : p
      );
    });

    setCart((prevCart) => prevCart.filter((_, index) => index !== indexToRemove));
  };

  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const placeOrder = async () => {
    if (!shippingAddress) {
      alert("Please enter a shipping address.");
      return;
    }
    try {
      const response = await fetch("http://localhost:8080/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: loggedInUserId,
          orderDate: new Date(),
          shippingAddress,
          totalPrice,
          status: "CLOSE",
          orderItems: cart.map(item => ({
            productId: item.id,
            quantity: item.quantity,
            price: item.price
          })),
        }),
      });
      if (!response.ok) throw new Error("Failed to place order");
      const data = await response.json();
      alert(`✅ Order placed! Order ID: ${data.id}`);
      setCart([]);
      setShowOrders(true);
      navigate(`/order-success/${data.id}`);
    } catch (error) {
      alert("Failed to place order.");
    }
  };

  return (
    <>
      
      {favoriteMessage && (
        <div style={{
          position: "fixed",
          top: "1rem",
          right: "1rem",
          backgroundColor: "#4caf50",
          color: "white",
          padding: "1rem",
          borderRadius: "8px",
          zIndex: 1000,
          boxShadow: "0px 2px 8px rgba(0,0,0,0.2)"
        }}>
          {favoriteMessage}
        </div>
      )}

      <header style={{
        backgroundColor: "green",
        padding: "1rem",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      }}>
        <a href="/" style={{ textDecoration: "none", color: "inherit" }}>
          <h2 style={{ margin: 0, cursor: "pointer" }}>❎ GameStore</h2>
        </a>
        <nav style={{ display: "flex", alignItems: "center" }}>
          <a href="/about" style={{ marginLeft: '1rem', color: "blue" }}>About</a>
          <a href="/favorites" style={{ marginLeft: '1rem', color: "blue" }}>Favorites</a>
          {localStorage.getItem("isLoggedIn") === "true" && (
            <button
              onClick={() => setShowOrders(!showOrders)}
              style={{
                marginLeft: "1rem",
                padding: "0.5rem 1rem",
                cursor: "pointer",
                borderRadius: "4px",
                border: "none",
                backgroundColor: "#fff",
                color: "green",
                fontWeight: "bold",
                fontSize: "14px"
              }}
            >
              {showOrders ? "Hide Orders" : "Show Orders"}
            </button>
          )}
        </nav>
      </header>

      <div style={{ padding: "2rem", backgroundColor: "yellow", minHeight: "100vh" }}>
        {showOrders && loggedInUserId && (
          <div style={{ marginBottom: "2rem" }}>
            <OrderList userId={loggedInUserId} />
          </div>
        )}

        <h1 style={{ fontFamily: "Arial Black", color: "#2c3e50", textAlign: "center" }}>
          ❎ GameStore
        </h1>

        <div style={{ textAlign: "center", marginBottom: "2rem" }}>
          <input
            type="text"
            placeholder="Search games 🔍"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ padding: "1rem", width: "300px", color: "red", background: "white" }}
          />
        </div>

        <div style={{ padding: "2rem" }}>
          {localStorage.getItem("isLoggedIn") === "true" ? (
            <button onClick={handleLogout}>Logout</button>
          ) : (
            <>
              <a href="/login" style={{ marginRight: "1rem" }}>Login</a>
              <a href="/signup">Sign Up</a>
            </>
          )}
        </div>

        <div style={{ padding: "2rem" }}>
          <button onClick={() => setSelectedCategory("all")}>All</button>
          <button onClick={() => setSelectedCategory("available")}>Available</button>
          <button onClick={() => setSelectedCategory("unavailable")}>Unavailable</button>
        </div>

        <div style={{ display: "flex", flexWrap: "wrap", gap: "1rem", justifyContent: "center" }}>
          {filteredProducts.map((item) => (
            <div
              key={item.id}
              style={{
                border: "1px solid #ccc",
                borderRadius: "8px",
                padding: "1rem",
                width: "120px",
                textAlign: "center",
              }}
            >
              <img
                src={item.image}
                alt={item.title}
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = "https://via.placeholder.com/200x150.png?text=No+Image";
                }}
                style={{ width: "100%", height: "150px", objectFit: "cover" }}
              />
              <h3>{item.title}</h3>
              <p>Price: ${item.price.toFixed(2)}</p>
              <p style={{ color: item.stock > 0 ? "green" : "red" }}>
                {item.stock > 0 ? `${item.stock} in stock` : "Out of stock"}
              </p>
              <button
                onClick={() => addToCart(item)}
                disabled={item.stock === 0}
              >
                add cart 🛒
              </button>
              <button
                onClick={() =>
                  favorites.includes(item.id)
                    ? removeFromFavorites(item.id)
                    : addToFavorites(item)
                }
                style={{
                  background: "none",
                  border: "none",
                  fontSize: "20px",
                  cursor: "pointer",
                  marginTop: "0.5rem"
                }}
                title={favorites.includes(item.id) ? "Remove from favorites" : "Add to favorites"}
              >
                {favorites.includes(item.id) ? "🌟" : "⭐"}
              </button>
            </div>
          ))}
        </div>

        <div style={{ marginTop: "3rem", padding: "2rem", borderTop: "2px solid #ddd" }}>
          <h2>🛒 Cart</h2>
          {cart.length === 0 ? (
            <p>Your cart is empty.</p>
          ) : (
            <>
              <ul>
                {cart.map((item, index) => (
                  <li key={index}>
                    {item.title} — ${item.price.toFixed(2)} × {item.quantity}
                    <button
                      onClick={() => removeFromCart(index)}
                      style={{
                        marginLeft: "10px",
                        color: "white",
                        backgroundColor: "red",
                        border: "none",
                        padding: "2px 8px",
                        borderRadius: "4px",
                        cursor: "pointer",
                      }}
                    >
                      🗑 remove
                    </button>
                  </li>
                ))}
              </ul>

              <div style={{ marginTop: "2rem" }}>
                <h3>Shipping Address</h3>
                <input
                  type="text"
                  value={shippingAddress}
                  onChange={(e) => setShippingAddress(e.target.value)}
                  placeholder="Enter your shipping address"
                  style={{ width: "300px", padding: "0.5rem" }}
                />
              </div>

              <p style={{ marginTop: "1rem" }}><strong>Total:</strong> ${totalPrice.toFixed(2)}</p>

              <button
                onClick={placeOrder}
                style={{
                  marginTop: "1rem",
                  padding: "0.5rem 1rem",
                  fontWeight: "bold",
                  backgroundColor: "green",
                  color: "white",
                  border: "none",
                  borderRadius: "4px",
                  cursor: "pointer",
                }}
              >
                ✅ Place Order
              </button>
            </>
          )}
        </div>
      </div>
    </>
  );
}
