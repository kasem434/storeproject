package shopping.com.items.orders;

public enum OrderStatus {
    TEMP,
    CLOSE
}
