package shopping.com.items.control;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import shopping.com.items.orders.Order;
import shopping.com.items.orders.OrderItem;
import shopping.com.items.orders.OrderService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "http://localhost:3000") // adjust for your frontend origin
public class OrderController {

    @Autowired
    private OrderService orderService;

    // Get all orders for a user
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Order>> getUserOrders(@PathVariable Long userId) {
        List<Order> orders = orderService.getOrdersByUserId(userId);
        return ResponseEntity.ok(orders);
    }

    // Get TEMP order for user (if exists)
    @GetMapping("/user/{userId}/temp")
    public ResponseEntity<Order> getTempOrder(@PathVariable Long userId) {
        Optional<Order> tempOrder = orderService.getTempOrderByUserId(userId);
        return tempOrder.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.noContent().build());
    }

    // Add item to TEMP order
    @PostMapping("/user/{userId}/temp/items")
    public ResponseEntity<Order> addItemToTempOrder(@PathVariable Long userId, @RequestBody OrderItem item) {
        Order updatedOrder = orderService.addItemToTempOrder(userId, item);
        return ResponseEntity.ok(updatedOrder);
    }

    // Remove item from order
    @DeleteMapping("/items/{orderItemId}")
    public ResponseEntity<Void> removeItemFromOrder(@PathVariable Long orderItemId) {
        orderService.removeItemFromOrder(orderItemId);
        return ResponseEntity.noContent().build();
    }

    // Close TEMP order (finalize it)
    @PostMapping("/{orderId}/close")
    public ResponseEntity<Order> closeOrder(@PathVariable Long orderId, @RequestBody CloseOrderRequest request) {
        Order closedOrder = orderService.closeOrder(orderId, request.getShippingAddress());
        return ResponseEntity.ok(closedOrder);
    }

    // DTO for closing order (to accept shipping address)
    public static class CloseOrderRequest {
        private String shippingAddress;

        public String getShippingAddress() {
            return shippingAddress;
        }
        public void setShippingAddress(String shippingAddress) {
            this.shippingAddress = shippingAddress;
        }
    }
}
