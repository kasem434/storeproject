package shopping.com.items.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import shopping.com.items.products.Products;

public interface ProductsRepository extends JpaRepository<Products, Long> {
}