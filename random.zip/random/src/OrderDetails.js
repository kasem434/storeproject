import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

export default function OrderDetails() {
  const { orderId } = useParams();
  const [order, setOrder] = useState(null);
  const [shippingAddress, setShippingAddress] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`http://localhost:8080/api/orders/${orderId}`)
      .then(res => {
        setOrder(res.data);
        setShippingAddress(res.data.shippingAddress || "");
      })
      .catch(err => console.error("Failed to load order:", err));
  }, [orderId]);

  const confirmOrder = async () => {
    if (!shippingAddress) {
      alert("Please enter a shipping address.");
      return;
    }

    try {
      await axios.put(`http://localhost:8080/api/orders/${orderId}/close`, {
        shippingAddress: shippingAddress
      });

      alert("✅ Order confirmed!");
      navigate("/products"); // or wherever you want to go
    } catch (err) {
      console.error("Failed to confirm order:", err);
      alert("❌ Failed to confirm order.");
    }
  };

  if (!order) return <p>Loading...</p>;

  return (
    <div style={{ padding: "2rem" }}>
      <h2>📦 Order #{order.id}</h2>
      <p><strong>Status:</strong> {order.status}</p>
      <p><strong>Date:</strong> {new Date(order.orderDate).toLocaleString()}</p>
      <p><strong>Shipping Address:</strong> {order.shippingAddress}</p>

      <h4>Items:</h4>
      <ul>
        {order.orderItems.map(item => (
          <li key={item.id}>
            Product #{item.productId} — Quantity: {item.quantity} — Price: ${item.price}
          </li>
        ))}
      </ul>

      <p><strong>Total:</strong> ${order.totalPrice.toFixed(2)}</p>

      {order.status === "TEMP" && (
        <>
          <h4>Update Shipping Address</h4>
          <input
            type="text"
            value={shippingAddress}
            onChange={(e) => setShippingAddress(e.target.value)}
            placeholder="Enter shipping address"
            style={{ width: "300px", padding: "0.5rem" }}
          />
          <br />
          <button
            onClick={confirmOrder}
            style={{
              marginTop: "1rem",
              padding: "0.5rem 1rem",
              backgroundColor: "green",
              color: "white",
              border: "none",
              borderRadius: "4px",
              cursor: "pointer"
            }}
          >
            ✅ Confirm Order
          </button>
        </>
      )}
    </div>
  );
}
