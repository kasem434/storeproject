package shopping.com.items.control;

import org.springframework.web.bind.annotation.*;
import shopping.com.items.products.Products;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductsController {

    @GetMapping
    public List<Products> getAllProducts() {
        return List.of(
                new Products(1L, "Max Payne 2", 15.99, "https://m.media-amazon.com/images/I/41vDEl8z2EL._SY430_SX215_QL70_FMwebp_.jpg", 10),
                new Products(2L, "call of duty world at war", 29.99, "https://i.ebayimg.com/images/g/TasAAOSwYp5j2sw5/s-l1600.webp", 5),
                new Products(3L, "Assassin's Creed", 59.99, "https://www.platinumgameservices.co.uk/prodimgs/PGS_2414_1710157626.png", 0),
                new Products(4L, "bully", 59.99, "https://www.platinumgameservices.co.uk/prodimgs/Bully-Achievements-Xbox-360-Game.png", 10),
                new Products(5L, "far cry3", 29.99, "https://www.platinumgameservices.co.uk/prodimgs/Far-Cry-3-Achievements-Xbox-360-Game.png", 5),
                new Products(6L, "L.A. Noire", 79.99, "https://www.platinumgameservices.co.uk/prodimgs/L-A-Noire-Achievements-Xbox-360-Game.png", 0),
                new Products(7L, "Farming Simulator", 59.99, "https://www.platinumgameservices.co.uk/prodimgs/Farming-Simulator-15-Achievements-Xbox-360-Game.png", 10),
                new Products(8L, "gears of war 2", 29.99, "https://store-images.s-microsoft.com/image/apps.45516.65595136073047161.857e51a5-2b52-4c0e-8ac2-92b6b4609fc2.d6aede50-9d8f-4813-9417-fab3a1d88e74", 5),
                new Products(9L, "call of duty 4", 79.99, "https://store-images.s-microsoft.com/image/apps.23065.64885830279055674.bddbfbcd-ded1-4f52-b344-10a98e886656.ade407ea-be79-465b-871f-47885d7fb443", 0),
                new Products(10L, "red dead redemption", 79.99, "https://media.gamestop.com/i/gamestop/11102347/Red-Dead-Redemption-Game-of-the-Year-Edition?$pdp$", 19),
                new Products(11L, "prototype 2", 10.99, "https://m.media-amazon.com/images/I/71khkaxtd7L.jpg", 4),
                new Products(12L, "halo 2", 1.99, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTtEmsBu32HDeNbZxvcX-17zUwlrsFqqw1DDQ&s", 33),
                new Products(13L, "halo 3", 2.99, "https://m.media-amazon.com/images/I/813gXz6Vi0L.jpg", 21),
                new Products(14L, "halo 4", 4.99, "https://m.media-amazon.com/images/I/91T4yYM0eGL._AC_UF894,1000_QL80_.jpg", 12),
                new Products(15L, "halo", 1.99, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRi5ZXEdnrC1LH124dwiB51vjQj19SsXZBWTA&s", 0)
        );
    }
}
