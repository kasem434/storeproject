import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const OrderList = ({ userId }) => {
  const [orders, setOrders] = useState([]);
  const [showOrders, setShowOrders] = useState(false);

  useEffect(() => {
    if (showOrders && userId) {
      axios.get(`http://localhost:8080/api/orders/user/${userId}`)
        .then(response => {
          setOrders(response.data);
        })
        .catch(error => {
          console.error('Error fetching orders:', error);
        });
    }
  }, [userId, showOrders]);

  return (
    <div style={{ marginBottom: '2rem' }}>
      <button
        onClick={() => setShowOrders(!showOrders)}
        style={{
          marginBottom: '1rem',
          padding: '8px 16px',
          backgroundColor: '#4CAF50',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer'
        }}
      >
        {showOrders ? 'Hide Orders' : 'Show Orders'}
      </button>

      {showOrders && (
        <>
          <h2 style={{ color: '#333' }}>🗂 Your Orders</h2>

          {orders.length === 0 ? (
            <p>No orders found.</p>
          ) : (
            orders.map(order => (
              <div
                key={order.id}
                style={{
                  border: '1px solid #ccc',
                  borderRadius: '6px',
                  padding: '12px',
                  marginBottom: '15px',
                  backgroundColor: '#f9f9f9'
                }}
              >
                <p><strong>Order ID:</strong> {order.id}</p>
                <p><strong>Date:</strong> {new Date(order.orderDate).toLocaleString()}</p>
                <p><strong>Status:</strong> {order.status}</p>
                <p><strong>Total:</strong> ${order.totalPrice.toFixed(2)}</p>
                <p><strong>Shipping Address:</strong> {order.shippingAddress}</p>

                <h4>Items:</h4>
                <ul>
                  {order.items.map(item => (
                    <li key={item.id}>
                      Product #{item.productId} — Quantity: {item.quantity} — Price: ${item.price.toFixed(2)}
                    </li>
                  ))}
                </ul>

                {order.status === "TEMP" ? (
                  <Link
                    to={`/order/${order.id}/edit`}
                    style={{ color: 'blue', fontWeight: 'bold' }}
                  >
                    🛠 Edit Order
                  </Link>
                ) : (
                  <Link
                    to={`/order/${order.id}`}
                    style={{ color: 'gray', fontWeight: 'bold' }}
                  >
                    📦 View Order
                  </Link>
                )}
              </div>
            ))
          )}
        </>
      )}
    </div>
  );
};

export default OrderList;
