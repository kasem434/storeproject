import React from "react";

export default function Page() {
  return (
    <div style={{ padding: "2rem", maxWidth: "800px", margin: "auto" }}>
      <h1 style={{ textAlign: "center", color: "#2c3e50" }}>About GameStore</h1>
      <p style={{ fontSize: "1.1rem", lineHeight: "1.6", marginTop: "1rem" }}>
        🎮 Welcome to <strong>GameStore</strong> — here you can find classic xbox 360 and original xbox games.
        have you ever wanted to play og games well this is the place for you,<strong>in our website</strong>
      </p>
      <p>
        We’re passionate about gaming, and we aim to bring you a hand-picked selection of Xbox games
      </p>
      <p>
        <strong>for more information please contact us</strong>
        <p>admin@Gmail.com</p>
      </p>
      <p style={{ marginTop: "2rem", fontStyle: "italic" }}>
        Thank you for visiting and happy gaming! 🕹️
      </p>
    </div>
  );
}