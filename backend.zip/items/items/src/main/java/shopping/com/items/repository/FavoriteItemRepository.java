package shopping.com.items.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import shopping.com.items.service.FavoriteItem;

import java.util.List;

public interface FavoriteItemRepository extends JpaRepository<FavoriteItem, Long> {
    List<FavoriteItem> findByUserId(Long userId);
    void deleteByUserIdAndProductId(Long userId, Long productId);
}
