//package shopping.com.items.products;
//
//import org.springframework.boot.CommandLineRunner;
//import org.springframework.stereotype.Component;
//import shopping.com.items.repository.ProductRepository;
//
//@Component
//public class DataInitializer implements CommandLineRunner {
//
//    private final ProductRepository productRepository;
//
//    public DataInitializer(ProductRepository productRepository) {
//        this.productRepository = productRepository;
//    }
//
//    @Override
//    public void run(String... args) throws Exception {
//        if (productRepository.count() == 0) {
//            productRepository.save(new Product("Max Payne 2", 15.99, 10,
//                    "https://m.media-amazon.com/images/I/41vDEl8z2EL._SY430_SX215_QL70_FMwebp_.jpg"));
//            productRepository.save(new Product("Call of Duty World at War", 29.99, 5,
//                    "https://i.ebayimg.com/images/g/TasAAOSwYp5j2sw5/s-l1600.webp"));
//            productRepository.save(new Product("Assassin's Creed", 59.99, 0,
//                    "https://www.platinumgameservices.co.uk/prodimgs/PGS_2414_1710157626.png"));
//            productRepository.save(new Product("Bully", 59.99, 10,
//                    "https://www.platinumgameservices.co.uk/prodimgs/Bully-Achievements-Xbox-360-Game.png"));
//            // add more products as needed
//        }
//    }
//}
