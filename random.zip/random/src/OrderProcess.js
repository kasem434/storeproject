import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

export default function OrderProcess() {
  const { orderId } = useParams();
  const [order, setOrder] = useState(null);
  const [address, setAddress] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`http://localhost:8080/api/orders/${orderId}`)
      .then(res => {
        setOrder(res.data);
        setAddress(res.data.shippingAddress || "");
      });
  }, [orderId]);

  const handlePlaceOrder = () => {
    axios.patch(`http://localhost:8080/api/orders/${orderId}/close`)
      .then(() => navigate(`/order/${orderId}`))
      .catch(() => alert("Failed to place order"));
  };

  if (!order) return <p>Loading...</p>;

  return (
    <div style={{ padding: "2rem" }}>
      <h2>🛠 Edit Order #{order.id}</h2>
      <p>Status: {order.status}</p>

      <div>
        <h4>Items:</h4>
        <ul>
          {order.items.map(item => (
            <li key={item.id}>
              Product #{item.productId} — Quantity: {item.quantity} — Price: ${item.price}
            </li>
          ))}
        </ul>
      </div>

      <div>
        <label>Shipping Address:</label><br />
        <input
          value={address}
          onChange={e => setAddress(e.target.value)}
          style={{ width: "300px", padding: "8px" }}
        />
      </div>

      <button onClick={handlePlaceOrder} style={{ marginTop: "1rem" }}>
        ✅ Place Order
      </button>
    </div>
  );
}
