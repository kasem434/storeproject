// OrdersStat.jsx
import { useEffect, useState } from "react";
import axios from "axios";

export default function OrdersStat({ userId, onSelectOrder }) {
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (!userId) return;
    axios.get(`http://localhost:8080/api/orders/user/${userId}`)
      .then(res => setOrders(res.data))
      .catch(err => console.error("Error fetching orders:", err));
  }, [userId]);

  if (!orders.length) return <p>No orders found.</p>;

  return (
    <div>
      <h2>Your Orders</h2>
      <ul style={{ listStyle: "none", padding: 0 }}>
        {orders.map(order => (
          <li 
            key={order.id} 
            onClick={() => onSelectOrder(order)}
            style={{ 
              cursor: "pointer", 
              margin: "1rem 0", 
              border: "1px solid #ccc", 
              padding: "1rem", 
              borderRadius: "8px",
              backgroundColor: order.status === "TEMP" ? "#fff8dc" : "#f0f0f0"
            }}
          >
            <p><strong>Order ID:</strong> {order.id}</p>
            <p><strong>Status:</strong> {order.status}</p>
            <p><strong>Date:</strong> {new Date(order.orderDate).toLocaleString()}</p>
            <p><strong>Total:</strong> ${order.totalPrice.toFixed(2)}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
