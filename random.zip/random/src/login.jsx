import { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

export default function LoginForm({ onLoginSuccess }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError(null);

    try {
      const response = await axios.post("http://localhost:8080/api/auth/login", {
        email,
        password,
      });

      console.log("Login response data:", response.data);

      if (response.data?.message === "Login successful" && response.data?.user) {
        const user = response.data.user;

        alert("Login successful!");

        // Store useful user data for session
        localStorage.setItem("isLoggedIn", "true");
        localStorage.setItem("userEmail", user.email);
        localStorage.setItem("userId", user.id);

        // Notify parent component of logged-in user to load favorites etc.
        if (onLoginSuccess) {
          onLoginSuccess(user);
        }

        // Redirect to home or dashboard
        navigate("/");
      } else {
        setError("Invalid credentials or unexpected response");
      }
    } catch (err) {
      console.error("Axios error:", err);
      if (err.response) {
        console.log("Backend response:", err.response.data);
        console.log("Status code:", err.response.status);
        if (err.response.status === 401) {
          setError("Invalid email or password.");
        } else {
          setError("Something went wrong. Status: " + err.response.status);
        }
      } else {
        setError("Network error or server is down.");
      }
    }
  };

  return (
    <div style={{ maxWidth: "400px", margin: "auto", padding: "9rem" }}>
      <h2>Login</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <form onSubmit={handleLogin}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          required
          onChange={(e) => setEmail(e.target.value)}
          style={{ width: "100%", marginBottom: "1rem", padding: "0.5rem" }}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          required
          onChange={(e) => setPassword(e.target.value)}
          style={{ width: "100%", marginBottom: "1rem", padding: "0.5rem" }}
        />
        <button type="submit" style={{ width: "100%", padding: "0.5rem" }}>
          Login
        </button>
      </form>
    </div>
  );
}
